<?php
require_once 'db_connection.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Read customer(s)
        if (isset($_GET['id'])) {
            // Get single customer
            $id = sanitizeInput($_GET['id']);
            $stmt = $conn->prepare("SELECT * FROM customers WHERE customer_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $customer = $result->fetch_assoc();
                echo json_encode($customer);
            } else {
                http_response_code(404);
                echo json_encode(["success" => false, "message" => "Customer not found"]);
            }
        } else {
            // Get all customers
            $result = $conn->query("SELECT * FROM customers");
            $customers = [];
            
            while ($row = $result->fetch_assoc()) {
                $customers[] = $row;
            }
            
            echo json_encode($customers);
        }
        break;
        
    case 'POST':
        // Create new customer
        $data = json_decode(file_get_contents("php://input"), true);
        
        $name = sanitizeInput($data['name']);
        $email = sanitizeInput($data['email']);
        $phone = sanitizeInput($data['phone']);
        $address = sanitizeInput($data['address']);
        
        $stmt = $conn->prepare("INSERT INTO customers (name, email, phone, address) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $phone, $address);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Customer created successfully"]);
        } else {
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Error creating customer"]);
        }
        break;
        
    case 'PUT':
        // Update customer
        $id = sanitizeInput($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        
        $name = sanitizeInput($data['name']);
        $email = sanitizeInput($data['email']);
        $phone = sanitizeInput($data['phone']);
        $address = sanitizeInput($data['address']);
        
        $stmt = $conn->prepare("UPDATE customers SET name=?, email=?, phone=?, address=? WHERE customer_id=?");
        $stmt->bind_param("ssssi", $name, $email, $phone, $address, $id);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Customer updated successfully"]);
        } else {
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Error updating customer"]);
        }
        break;
        
    case 'DELETE':
        // Delete customer
        $id = sanitizeInput($_GET['id']);
        
        $stmt = $conn->prepare("DELETE FROM customers WHERE customer_id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Customer deleted successfully"]);
        } else {
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Error deleting customer"]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(["success" => false, "message" => "Method not allowed"]);
        break;
}

$conn->close();
?>