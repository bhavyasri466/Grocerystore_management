<?php
require_once 'db_connection.php';

$data = json_decode(file_get_contents("php://input"), true);

$username = sanitizeInput($data['username'] ?? '');
$password = $data['password'] ?? '';

try {
    // Get user from database
    $stmt = $conn->prepare("SELECT user_id, username, password_hash FROM users WHERE username = ? AND is_active = TRUE");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
        exit;
    }
    
    $user = $result->fetch_assoc();
    
    if (password_verify($password, $user['password_hash'])) {
        // Update last login (using a separate query)
        $updateStmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?");
        $updateStmt->bind_param("i", $user['user_id']);
        $updateStmt->execute();
        $updateStmt->close();
        
        // Start session
        session_start();
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        
        // Regenerate session ID to prevent session fixation
        session_regenerate_id(true);
        
        echo json_encode([
            'success' => true,
            'message' => 'Login successful',
            'user' => [
                'id' => $user['user_id'],
                'username' => $user['username']
            ]
        ]);
    } else {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Login failed',
        'error' => $e->getMessage()
    ]);
} finally {
    // Close statements if they exist
    if (isset($stmt)) {
        $stmt->close();
    }
    if (isset($updateStmt)) {
        $updateStmt->close();
    }
    // Note: Don't close $conn here as it's used by other functions
}
?>