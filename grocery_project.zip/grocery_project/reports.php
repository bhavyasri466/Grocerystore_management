<?php
require_once 'db_connection.php';

$type = sanitizeInput($_GET['type']);
$startDate = isset($_GET['start_date']) ? sanitizeInput($_GET['start_date']) : null;
$endDate = isset($_GET['end_date']) ? sanitizeInput($_GET['end_date']) : null;

$response = [];

switch ($type) {
    case 'sales':
        // Sales report
        $query = "
            SELECT o.order_id, o.order_date, c.name AS customer_name, o.total_amount, o.status 
            FROM orders o
            JOIN customers c ON o.customer_id = c.customer_id
        ";
        
        $where = [];
        $params = [];
        $types = '';
        
        if ($startDate) {
            $where[] = "o.order_date >= ?";
            $params[] = $startDate;
            $types .= 's';
        }
        
        if ($endDate) {
            $where[] = "o.order_date <= ?";
            $params[] = $endDate;
            $types .= 's';
        }
        
        if (!empty($where)) {
            $query .= " WHERE " . implode(" AND ", $where);
        }
        
        $query .= " ORDER BY o.order_date DESC";
        
        $stmt = $conn->prepare($query);
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $response['orders'] = [];
        while ($row = $result->fetch_assoc()) {
            $response['orders'][] = $row;
        }
        
        // Calculate total sales
        $query = "SELECT COALESCE(SUM(total_amount), 0) AS total FROM orders";
        
        if (!empty($where)) {
            $query .= " WHERE " . implode(" AND ", $where);
        }
        
        $stmt = $conn->prepare($query);
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $response['total_sales'] = floatval($result->fetch_assoc()['total']);
        break;
        
    case 'inventory':
        // Inventory report
        $result = $conn->query("
            SELECT product_id, name, category, price, quantity 
            FROM products 
            ORDER BY category, name
        ");
        
        $response['products'] = [];
        while ($row = $result->fetch_assoc()) {
            $response['products'][] = $row;
        }
        
        // Calculate total inventory value
        $result = $conn->query("
            SELECT COALESCE(SUM(price * quantity), 0) AS total 
            FROM products
        ");
        $response['total_value'] = floatval($result->fetch_assoc()['total']);
        break;
        
    case 'customer':
        // Customer report
        $query = "
            SELECT 
                c.customer_id, 
                c.name, 
                c.email, 
                c.phone,
                COUNT(o.order_id) AS order_count,
                COALESCE(SUM(o.total_amount), 0) AS total_spent
            FROM customers c
            LEFT JOIN orders o ON c.customer_id = o.customer_id
        ";
        
        $where = [];
        $params = [];
        $types = '';
        
        if ($startDate) {
            $where[] = "o.order_date >= ?";
            $params[] = $startDate;
            $types .= 's';
        }
        
        if ($endDate) {
            $where[] = "o.order_date <= ?";
            $params[] = $endDate;
            $types .= 's';
        }
        
        if (!empty($where)) {
            $query .= " WHERE " . implode(" AND ", $where);
        }
        
        $query .= " GROUP BY c.customer_id ORDER BY total_spent DESC";
        
        $stmt = $conn->prepare($query);
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $response['customers'] = [];
        while ($row = $result->fetch_assoc()) {
            $response['customers'][] = $row;
        }
        break;
        
    default:
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Invalid report type"]);
        exit;
}

echo json_encode($response);

$conn->close();
?>