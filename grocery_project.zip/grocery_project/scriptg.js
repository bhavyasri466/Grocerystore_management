// Order item management
document.getElementById('add-item-btn').addEventListener('click', function() {
    const itemsContainer = document.getElementById('order-items-container');
    const newItem = document.createElement('div');
    newItem.className = 'order-item';
    newItem.innerHTML = `
        <select class="order-item-product" required>
            <option value="">Select Product</option>
        </select>
        <input type="number" class="order-item-quantity" min="1" value="1" required>
        <input type="number" class="order-item-price" readonly>
        <button type="button" class="remove-item-btn">Remove</button>
    `;
    
    // Populate product dropdown
    fetch('api/products.php')
        .then(response => response.json())
        .then(products => {
            const select = newItem.querySelector('.order-item-product');
            products.forEach(product => {
                const option = document.createElement('option');
                option.value = product.product_id;
                option.textContent = `${product.name} ($${product.price.toFixed(2)})`;
                option.setAttribute('data-price', product.price);
                select.appendChild(option);
            });
        });
    
    itemsContainer.appendChild(newItem);
    
    // Add event listeners to the new item
    newItem.querySelector('.order-item-product').addEventListener('change', updateOrderItemPrice);
    newItem.querySelector('.order-item-quantity').addEventListener('input', updateOrderTotal);
    newItem.querySelector('.remove-item-btn').addEventListener('click', function() {
        itemsContainer.removeChild(newItem);
        updateOrderTotal();
    });
});

// Update order item price when product is selected
function updateOrderItemPrice(e) {
    const select = e.target;
    const priceInput = select.closest('.order-item').querySelector('.order-item-price');
    const selectedOption = select.options[select.selectedIndex];
    
    if (selectedOption && selectedOption.value) {
        priceInput.value = selectedOption.getAttribute('data-price');
    } else {
        priceInput.value = '';
    }
    
    updateOrderTotal();
}

// Update order total amount
function updateOrderTotal() {
    let total = 0;
    
    document.querySelectorAll('.order-item').forEach(item => {
        const quantity = parseFloat(item.querySelector('.order-item-quantity').value) || 0;
        const price = parseFloat(item.querySelector('.order-item-price').value) || 0;
        total += quantity * price;
    });
    
    document.getElementById('order-total-amount').textContent = total.toFixed(2);
}

// Add event listeners to existing order items
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.order-item-product').forEach(select => {
        select.addEventListener('change', updateOrderItemPrice);
    });
    
    document.querySelectorAll('.order-item-quantity').forEach(input => {
        input.addEventListener('input', updateOrderTotal);
    });
    
    document.querySelectorAll('.remove-item-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const item = this.closest('.order-item');
            if (document.querySelectorAll('.order-item').length > 1) {
                item.parentNode.removeChild(item);
                updateOrderTotal();
            }
        });
    });
});

// View order details
function viewOrder(id) {
    fetch(`api/orders.php?id=${id}`)
        .then(response => response.json())
        .then(order => {
            let itemsHtml = '';
            order.items.forEach(item => {
                itemsHtml += `
                    <tr>
                        <td>${item.product_name}</td>
                        <td>${item.quantity}</td>
                        <td>$${item.price.toFixed(2)}</td>
                        <td>$${(item.quantity * item.price).toFixed(2)}</td>
                    </tr>
                `;
            });
            
            const modalHtml = `
                <div class="modal" id="view-order-modal" style="display: block;">
                    <div class="modal-content" style="max-width: 800px;">
                        <span class="close" onclick="document.getElementById('view-order-modal').style.display='none'">&times;</span>
                        <h2>Order #${order.order_id}</h2>
                        <div class="order-details">
                            <p><strong>Customer:</strong> ${order.customer_name}</p>
                            <p><strong>Date:</strong> ${order.order_date}</p>
                            <p><strong>Status:</strong> ${order.status}</p>
                        </div>
                        <h3>Order Items</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${itemsHtml}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" style="text-align: right;"><strong>Order Total:</strong></td>
                                    <td><strong>$${order.total_amount.toFixed(2)}</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            `;
            
            const modalContainer = document.createElement('div');
            modalContainer.innerHTML = modalHtml;
            document.body.appendChild(modalContainer);
        })
        .catch(error => console.error('Error:', error));
}

// Edit order
function editOrder(id) {
    fetch(`api/orders.php?id=${id}`)
        .then(response => response.json())
        .then(order => {
            modals.order.title.textContent = 'Edit Order';
            document.getElementById('order-id').value = order.order_id;
            document.getElementById('order-customer').value = order.customer_id;
            document.getElementById('order-status').value = order.status;
            
            // Clear existing items
            const itemsContainer = document.getElementById('order-items-container');
            itemsContainer.innerHTML = '';
            
            // Load products for dropdown
            fetch('api/products.php')
                .then(response => response.json())
                .then(products => {
                    // Add items from the order
                    order.items.forEach(item => {
                        const itemDiv = document.createElement('div');
                        itemDiv.className = 'order-item';
                        itemDiv.innerHTML = `
                            <select class="order-item-product" required>
                                <option value="">Select Product</option>
                            </select>
                            <input type="number" class="order-item-quantity" min="1" value="${item.quantity}" required>
                            <input type="number" class="order-item-price" readonly value="${item.price}">
                            <button type="button" class="remove-item-btn">Remove</button>
                        `;
                        
                        const select = itemDiv.querySelector('.order-item-product');
                        
                        // Populate product dropdown
                        products.forEach(product => {
                            const option = document.createElement('option');
                            option.value = product.product_id;
                            option.textContent = `${product.name} ($${product.price.toFixed(2)})`;
                            option.setAttribute('data-price', product.price);
                            select.appendChild(option);
                            
                            // Select the current product
                            if (product.product_id == item.product_id) {
                                option.selected = true;
                            }
                        });
                        
                        itemsContainer.appendChild(itemDiv);
                        
                        // Add event listeners to the new item
                        select.addEventListener('change', updateOrderItemPrice);
                        itemDiv.querySelector('.order-item-quantity').addEventListener('input', updateOrderTotal);
                        itemDiv.querySelector('.remove-item-btn').addEventListener('click', function() {
                            if (document.querySelectorAll('.order-item').length > 1) {
                                itemsContainer.removeChild(itemDiv);
                                updateOrderTotal();
                            }
                        });
                    });
                    
                    // Update total
                    document.getElementById('order-total-amount').textContent = order.total_amount.toFixed(2);
                });
            
            modals.order.modal.style.display = 'block';
        })
        .catch(error => console.error('Error:', error));
}

// Delete order
function deleteOrder(id) {
    if (confirm('Are you sure you want to delete this order?')) {
        fetch(`api/orders.php?id=${id}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadOrders();
                loadDashboard(); // Update stats
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => console.error('Error:', error));
    }
}

// Generate report
document.getElementById('generate-report-btn').addEventListener('click', function() {
    const reportType = document.getElementById('report-type').value;
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;
    
    let url = `api/reports.php?type=${reportType}`;
    if (startDate) url += `&start_date=${startDate}`;
    if (endDate) url += `&end_date=${endDate}`;
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            const reportResults = document.getElementById('report-results');
            reportResults.innerHTML = '';
            
            switch(reportType) {
                case 'sales':
                    reportResults.innerHTML = generateSalesReport(data);
                    break;
                case 'inventory':
                    reportResults.innerHTML = generateInventoryReport(data);
                    break;
                case 'customer':
                    reportResults.innerHTML = generateCustomerReport(data);
                    break;
            }
        })
        .catch(error => console.error('Error:', error));
});

function generateSalesReport(data) {
    let html = `<h3>Sales Report</h3>`;
    
    if (data.orders && data.orders.length > 0) {
        html += `
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Date</th>
                        <th>Customer</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        data.orders.forEach(order => {
            html += `
                <tr>
                    <td>${order.order_id}</td>
                    <td>${order.order_date}</td>
                    <td>${order.customer_name}</td>
                    <td>$${order.total_amount.toFixed(2)}</td>
                    <td>${order.status}</td>
                </tr>
            `;
        });
        
        html += `
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" style="text-align: right;"><strong>Total Sales:</strong></td>
                        <td><strong>$${data.total_sales.toFixed(2)}</strong></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        `;
    } else {
        html += `<p>No sales data found for the selected period.</p>`;
    }
    
    return html;
}

function generateInventoryReport(data) {
    let html = `<h3>Inventory Report</h3>`;
    
    if (data.products && data.products.length > 0) {
        html += `
            <table>
                <thead>
                    <tr>
                        <th>Product ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Stock Value</th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        data.products.forEach(product => {
            const stockValue = product.price * product.quantity;
            html += `
                <tr>
                    <td>${product.product_id}</td>
                    <td>${product.name}</td>
                    <td>${product.category}</td>
                    <td>$${product.price.toFixed(2)}</td>
                    <td>${product.quantity}</td>
                    <td>$${stockValue.toFixed(2)}</td>
                </tr>
            `;
        });
        
        html += `
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5" style="text-align: right;"><strong>Total Inventory Value:</strong></td>
                        <td><strong>$${data.total_value.toFixed(2)}</strong></td>
                    </tr>
                </tfoot>
            </table>
        `;
    } else {
        html += `<p>No inventory data found.</p>`;
    }
    
    return html;
}

function generateCustomerReport(data) {
    let html = `<h3>Customer Report</h3>`;
    
    if (data.customers && data.customers.length > 0) {
        html += `
            <table>
                <thead>
                    <tr>
                        <th>Customer ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Total Orders</th>
                        <th>Total Spent</th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        data.customers.forEach(customer => {
            html += `
                <tr>
                    <td>${customer.customer_id}</td>
                    <td>${customer.name}</td>
                    <td>${customer.email}</td>
                    <td>${customer.phone}</td>
                    <td>${customer.order_count}</td>
                    <td>$${customer.total_spent.toFixed(2)}</td>
                </tr>
            `;
        });
        
        html += `
                </tbody>
            </table>
        `;
    } else {
        html += `<p>No customer data found.</p>`;
    }
    
    return html;
}