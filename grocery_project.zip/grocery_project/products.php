<?php
require_once 'db_connection.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Read product(s)
        if (isset($_GET['id'])) {
            // Get single product
            $id = sanitizeInput($_GET['id']);
            $stmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $product = $result->fetch_assoc();
                echo json_encode($product);
            } else {
                http_response_code(404);
                echo json_encode(["success" => false, "message" => "Product not found"]);
            }
        } else {
            // Get all products
            $result = $conn->query("SELECT * FROM products");
            $products = [];
            
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
            
            echo json_encode($products);
        }
        break;
        
    case 'POST':
        // Create new product
        $data = json_decode(file_get_contents("php://input"), true);
        
        $name = sanitizeInput($data['name']);
        $description = sanitizeInput($data['description']);
        $price = floatval($data['price']);
        $quantity = intval($data['quantity']);
        $category = sanitizeInput($data['category']);
        
        $stmt = $conn->prepare("INSERT INTO products (name, description, price, quantity, category) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdis", $name, $description, $price, $quantity, $category);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Product created successfully"]);
        } else {
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Error creating product"]);
        }
        break;
        
    case 'PUT':
        // Update product
        $id = sanitizeInput($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        
        $name = sanitizeInput($data['name']);
        $description = sanitizeInput($data['description']);
        $price = floatval($data['price']);
        $quantity = intval($data['quantity']);
        $category = sanitizeInput($data['category']);
        
        $stmt = $conn->prepare("UPDATE products SET name=?, description=?, price=?, quantity=?, category=? WHERE product_id=?");
        $stmt->bind_param("ssdisi", $name, $description, $price, $quantity, $category, $id);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Product updated successfully"]);
        } else {
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Error updating product"]);
        }
        break;
        
    case 'DELETE':
        // Delete product
        $id = sanitizeInput($_GET['id']);
        
        $stmt = $conn->prepare("DELETE FROM products WHERE product_id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Product deleted successfully"]);
        } else {
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Error deleting product"]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(["success" => false, "message" => "Method not allowed"]);
        break;
}

$conn->close();
?>