<?php
require_once 'db_connection.php';

// Get dashboard statistics
$response = [];

// Total products
$result = $conn->query("SELECT COUNT(*) AS total FROM products");
$response['total_products'] = $result->fetch_assoc()['total'];

// Total customers
$result = $conn->query("SELECT COUNT(*) AS total FROM customers");
$response['total_customers'] = $result->fetch_assoc()['total'];

// Total orders
$result = $conn->query("SELECT COUNT(*) AS total FROM orders");
$response['total_orders'] = $result->fetch_assoc()['total'];

// Total revenue
$result = $conn->query("SELECT COALESCE(SUM(total_amount), 0) AS total FROM orders");
$response['total_revenue'] = floatval($result->fetch_assoc()['total']);

// Recent orders (last 5)
$result = $conn->query("
    SELECT o.order_id, c.name AS customer_name, o.order_date, o.total_amount, o.status 
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
    ORDER BY o.order_date DESC
    LIMIT 5
");

$response['recent_orders'] = [];
while ($row = $result->fetch_assoc()) {
    $response['recent_orders'][] = $row;
}

echo json_encode($response);

$conn->close();
?>