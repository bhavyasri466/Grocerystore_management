<?php
require_once 'db_connection.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Read order(s)
        if (isset($_GET['id'])) {
            // Get single order with items
            $id = sanitizeInput($_GET['id']);
            
            // Get order details
            $stmt = $conn->prepare("
                SELECT o.*, c.name AS customer_name 
                FROM orders o
                JOIN customers c ON o.customer_id = c.customer_id
                WHERE o.order_id = ?
            ");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                http_response_code(404);
                echo json_encode(["success" => false, "message" => "Order not found"]);
                exit;
            }
            
            $order = $result->fetch_assoc();
            
            // Get order items
            $stmt = $conn->prepare("
                SELECT oi.*, p.name AS product_name 
                FROM order_items oi
                JOIN products p ON oi.product_id = p.product_id
                WHERE oi.order_id = ?
            ");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $itemsResult = $stmt->get_result();
            
            $items = [];
            while ($row = $itemsResult->fetch_assoc()) {
                $items[] = $row;
            }
            
            $order['items'] = $items;
            echo json_encode($order);
        } else {
            // Get all orders with customer names
            $result = $conn->query("
                SELECT o.*, c.name AS customer_name 
                FROM orders o
                JOIN customers c ON o.customer_id = c.customer_id
                ORDER BY o.order_date DESC
            ");
            
            $orders = [];
            while ($row = $result->fetch_assoc()) {
                $orders[] = $row;
            }
            
            echo json_encode($orders);
        }
        break;
        
    case 'POST':
        // Create new order
        $data = json_decode(file_get_contents("php://input"), true);
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Insert order
            $customerId = intval($data['customer_id']);
            $status = sanitizeInput($data['status']);
            $totalAmount = 0;
            
            // Calculate total amount
            foreach ($data['items'] as $item) {
                $totalAmount += floatval($item['price']) * intval($item['quantity']);
            }
            
            $stmt = $conn->prepare("INSERT INTO orders (customer_id, total_amount, status) VALUES (?, ?, ?)");
            $stmt->bind_param("ids", $customerId, $totalAmount, $status);
            $stmt->execute();
            $orderId = $conn->insert_id;
            
            // Insert order items
            foreach ($data['items'] as $item) {
                $productId = intval($item['product_id']);
                $quantity = intval($item['quantity']);
                $price = floatval($item['price']);
                
                $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("iiid", $orderId, $productId, $quantity, $price);
                $stmt->execute();
                
                // Update product quantity
                $stmt = $conn->prepare("UPDATE products SET quantity = quantity - ? WHERE product_id = ?");
                $stmt->bind_param("ii", $quantity, $productId);
                $stmt->execute();
            }
            
            // Commit transaction
            $conn->commit();
            echo json_encode(["success" => true, "message" => "Order created successfully", "order_id" => $orderId]);
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Error creating order: " . $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        // Update order
        $id = sanitizeInput($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Update order details
            $customerId = intval($data['customer_id']);
            $status = sanitizeInput($data['status']);
            $totalAmount = 0;
            
            // Calculate new total amount
            foreach ($data['items'] as $item) {
                $totalAmount += floatval($item['price']) * intval($item['quantity']);
            }
            
            $stmt = $conn->prepare("UPDATE orders SET customer_id=?, total_amount=?, status=? WHERE order_id=?");
            $stmt->bind_param("idsi", $customerId, $totalAmount, $status, $id);
            $stmt->execute();
            
            // Delete existing order items
            $stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            
            // Insert new order items
            foreach ($data['items'] as $item) {
                $productId = intval($item['product_id']);
                $quantity = intval($item['quantity']);
                $price = floatval($item['price']);
                
                $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("iiid", $id, $productId, $quantity, $price);
                $stmt->execute();
            }
            
            // Commit transaction
            $conn->commit();
            echo json_encode(["success" => true, "message" => "Order updated successfully"]);
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Error updating order: " . $e->getMessage()]);
        }
        break;
        
    case 'DELETE':
        // Delete order
        $id = sanitizeInput($_GET['id']);
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // First delete order items
            $stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            
            // Then delete the order
            $stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            echo json_encode(["success" => true, "message" => "Order deleted successfully"]);
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Error deleting order: " . $e->getMessage()]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(["success" => false, "message" => "Method not allowed"]);
        break;
}

$conn->close();
?>